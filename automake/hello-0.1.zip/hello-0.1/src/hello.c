#include <stdio.h>

void PrintDate();

void hello()
{
    printf("Hello world!");
    PrintDate();
}
